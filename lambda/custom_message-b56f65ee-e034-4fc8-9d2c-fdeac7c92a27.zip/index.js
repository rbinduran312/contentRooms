exports.handler = (event, context, callback) => {
    if(event.triggerSource === "CustomMessage_SignUp") {
    // Ensure that your message contains event.request.codeParameter. This is the placeholder for code that will be sent
    const { codeParameter, linkParameter } = event.request;
    const { userName, region  } = event;
    const { clientId } = event.callerContext;
    const { email } = event.request.userAttributes;
    const url = `https://uau5yjek33.execute-api.us-east-1.amazonaws.com/prod/redirect?code=${codeParameter}&username=${userName}&region=${region}&clientId=${clientId}&email=${email}`;
    event.response.emailSubject = 'Please verify your email addresss'; 
    event.response.emailMessage = `
    <!DOCTYPE html>
      <html>
        Thanks for signing up
        <a href="${url}" 
            target="_blank" 
            style="display: inline-block; color: #ffffff; background-color: #3498db; border: solid 1px #3498db; border-radius: 5px; box-sizing: border-box; cursor: pointer; text-decoration: none; font-size: 14px; font-weight: bold; margin: 0; padding: 12px 25px; text-transform: capitalize; border-color: #3498db;">
            Verify
        </a>
        <div style="display: none">${linkParameter}</div>
      </html>
    `;
    }
// CallBack to the lambda for the email trigger
    callback(null, event);
};