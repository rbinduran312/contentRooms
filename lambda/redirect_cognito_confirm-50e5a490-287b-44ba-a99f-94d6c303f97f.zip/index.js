var AWS = require('aws-sdk');

exports.handler = async (request, context, callback) => {
    try {
        console.log("redirect cognito")
        console.log(request)
        const region = request.queryStringParameters.region;
        var cognito = new AWS.CognitoIdentityServiceProvider({
            apiVersion: '2019-11-07',
            region: region
        });
        
        console.log("cognito")
        const confirmationCode = request.queryStringParameters.code;
        const username = request.queryStringParameters.username;
        const clientId = request.queryStringParameters.clientId;

        const params = {
            ClientId: clientId,
            ConfirmationCode: confirmationCode,
            Username: username
        };

        await cognito.confirmSignUp(params).promise();
        
        return redirectResponse('Redirect succesfully');
    } catch (err) {
        console.log(err)
        return err;
    }
};


const redirectResponse = (message) => ({
    statusCode: 302,
    headers: {
        'Content-Type': 'application/json',
        'Access-Control-Expose-Headers': '*',
        'Access-Control-Allow-Credentials': true,
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*',
        Location: "http://localhost:3000/login" //link for your website here,
    },
    body: JSON.stringify(message),
});